from yardstick import _init_logging


_init_logging()
