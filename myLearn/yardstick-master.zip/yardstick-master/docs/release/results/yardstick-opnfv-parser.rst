.. This work is licensed under a Creative Commons Attribution 4.0 International
.. License.
.. http://creativecommons.org/licenses/by/4.0


=======================================
Test Results for yardstick-opnfv-parser
=======================================

.. toctree::
   :maxdepth: 2


Details
=======

.. after this doc is filled, remove all comments and include the scenario in
.. results.rst by removing the comment on the file name.


Overview of test results
------------------------

.. general on metrics collected, number of iterations

Detailed test results
---------------------

.. info on lab, installer, scenario

Rationale for decisions
-----------------------
.. result analysis, pass/fail

Conclusions and recommendations
-------------------------------

.. did the expected behavior occured?
